# Emacs Puppet Module for Boxen

Install [GNU Emacs](http://www.gnu.org/software/emacs), an operating
system desperately searching for a decent editor.

## Usage

```puppet
include emacs
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
